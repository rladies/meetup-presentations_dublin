
#### R Ladies 26/10/2017 - Introduction to Linear Regression in R ####


#### Example 1 - Simple linear regression and visualisation ####

## clear workspace 
rm(list = ls())


## Load cars data and investigate
cars <- cars
head(cars) # two continuous numerical variables: speed and distance


## Visualise with a scatter plot
plot(cars) # confirm that relationship could be approximated with a line


## Define formula and learn about class methods
form <- dist ~ speed
class(form)
?formula


## Fit simple model using lm()
?lm
carsLM <- lm(form, data = cars) # alternatively: lm(cars$dist ~ cars$speed) BUT might lead to problems later...
class(carsLM)


## Investigate the model 
coefficients(carsLM)
summary(carsLM)

plot(cars)
abline(carsLM, col = "red")


## Use the model to make a prediction
?predict
?predict.lm

# predict the stopping distance of a car going at speed 30
predict(carsLM, newdata = data.frame(speed = 30), type = "response") 

# predict multiple data points
toPredict <- data.frame(speed = c(5, 12, 27, 30, 37.5)) 
toPredict$dist <- predict(carsLM, newdata = toPredict, type = "r")

head(toPredict)

# create visualisation
newCars <- data.frame(cars)
newCars$col <- "grey"
toPredict$col <- "red"
newCars <- rbind.data.frame(newCars, toPredict)

plot(x = newCars$speed, y = newCars$dist, col = newCars$col)
abline(carsLM, col = "red")

# include 95% confidence interval in prediction
predict(carsLM, 
        newdata = data.frame(speed = 30), 
        type = "response", 
        interval = "prediction", 
        level = 0.95) 








## Solution to DIY 1

faithful <- faithful
plot(faithful)
ffLM <- lm(waiting ~ eruptions, data = faithful)
abline(ffLM, col = "red")
summary(ffLM)

toPredictFF <- data.frame(eruptions = c(1.2, 2.8))
toPredictFF$waiting <- predict(ffLM, 
        newdata = toPredictFF, 
        type = "response", 
        interval = "predict", 
        level = 0.95) 
toPredictFF


# visulisation (example, many different ways to get there or to a much better place!)

# original data
newFaithful <- data.frame(faithful)
newFaithful$col <- "grey"

# predicted values (extract from attributes of waiting column)
baseFitPred <- data.frame(eruptions = toPredictFF$eruptions, waiting = toPredictFF$waiting[,1])
baseFitPred$col <- "red"

# confidence intervals
lwrPred <- data.frame(eruptions = toPredictFF$eruptions, waiting = toPredictFF$waiting[,2])
lwrPred$col <- "blue"

uprPred <- data.frame(eruptions = toPredictFF$eruptions, waiting = toPredictFF$waiting[,3])
uprPred$col <- "blue"

#combine data and plot
newFaithful <- do.call(rbind.data.frame, list(newFaithful, baseFitPred, lwrPred, uprPred))

plot(newFaithful[,1:2], col = newFaithful[,3])
abline(ffLM, col = "red")






#### Multiple dependent variables and interactions: Walkthrough ####


# load dataset mtcars
library(car)
mtcars <- mtcars

# check linear relationships and distributions (assumptions)
scatterplotMatrix(~mpg+disp+drat+wt|cyl, data=mtcars,
                   main="Three Cylinder Options")


# fit first model
mtcarLM1 <- lm(cyl~mpg+disp+drat+wt, data = mtcars)

# investigate
summary(mtcarLM1)

# check assumptions by plotting model
plot(mtcarLM1)

# plot 1: check for curvilinear trends
# plot 2: check for normal distribution of residuals
# plot 3: check for heteroscedasticity (differing variance)
# plot 4: check for outliers


# fit second model, add interaction
mtcarLM2 <- lm(cyl~mpg+disp+drat+wt+mpg:disp, data = mtcars)
summary(mtcarLM2)


# compare models with ANOVA (analysis of variance)
comp12 <- anova(mtcarLM1, mtcarLM2)
print(comp12) # model 2 is slightly but not significantly better


# fit third model and compare again
mtcarLM3 <- lm(cyl~wt+drat, data = mtcars)
summary(mtcarLM3)

anova(mtcarLM2, mtcarLM3) # mtcarLM2 is significantly better






#### Example 2 - Logistc regression ####

## Load Data (American Workforce)
adult <- read.csv("http://rstatistics.net/wp-content/uploads/2015/09/adult.csv")
str(adult)

# check class bias
table(adult$ABOVE50K)

# split off subset
US <- subset(adult, adult$NATIVECOUNTRY == ' United-States')


## Build GLM to predict whether someone is making more than 50k

# fit model
US50KGLM1 <- glm(ABOVE50K ~ AGE + SEX + HOURSPERWEEK + MARITALSTATUS, data = US, family = binomial)
summary(US50KGLM1)
anova(US50KGLM1, test = "Chisq") # combines categoricals, chisq only for binomial and poisson

# predict probabilities for making above 50k
toPredict50k <- data.frame(AGE = 50, SEX = " Male", HOURSPERWEEK = 40, MARITALSTATUS = " Separated")
predict(US50KGLM1, toPredict50k, type = "response")








## Solution to DIY 2

nonUS <- subset(adult, adult$NATIVECOUNTRY != ' United-States')

nonUS50KGLM1 <- glm(ABOVE50K ~ AGE + SEX + HOURSPERWEEK + MARITALSTATUS, data = nonUS, family = binomial)
summary(nonUS50KGLM1)

nonUS50KGLM2 <- glm(ABOVE50K ~ AGE + RACE + HOURSPERWEEK + MARITALSTATUS, data = nonUS, family = binomial)
summary(nonUS50KGLM2)


anova(nonUS50KGLM1, nonUS50KGLM2)
pchisq(26.108, 3) # large p, no significant difference
anova(nonUS50KGLM1, test = "Chisq")
anova(nonUS50KGLM2, test = "Chisq")


toPredict50k <- data.frame(AGE = 40, RACE = " Black", HOURSPERWEEK = 60, MARITALSTATUS = " Widowed")
predict(nonUS50KGLM2, toPredict50k, type = "response")







#### Example 3 - Model Metrics and Full Model Build ####

## Split test and training (70%) data randomly using the sample() function
n <- nrow(US)
trainIndex <- sample(1:n, size = round(0.7*n), replace=FALSE)
trainUS <- US[trainIndex ,]
testUS <- US[-trainIndex ,]


## Fit previous model to training data
US50KGLM2 <- glm(ABOVE50K ~ AGE + SEX + HOURSPERWEEK + MARITALSTATUS, data = trainUS, family = binomial)
summary(US50KGLM2)


## Use model to predict test data
prediction <- predict(US50KGLM2, newdata = testUS, type = "response")

testUS$prediction <- prediction
head(testUS[,c("ABOVE50K", "prediction")])


## Plot histogram
hist(prediction)
hist(testUS$ABOVE50K)

hist(prediction, breaks = 2)
hist(testUS$ABOVE50K, breaks = 2)


## find optimal cutoff and create confusion matrix
library(InformationValue)
optCutOff <- optimalCutoff(testUS$ABOVE50K, prediction)[1] 

confusionMatrix(testUS$ABOVE50K, prediction, threshold = optCutOff)


## Plot ROC curve
plotROC(testUS$ABOVE50K, prediction)







## Solution to DIY 3

# insert github link here
titanic <- read.csv('C:/Users/ncber/Documents/Kaggle/TitanicSurvivors/train.csv', header = T)


n <- nrow(titanic)
trainIndex <- sample(1:n, size = round(0.7*n), replace=FALSE)
train <- titanic[trainIndex ,]
test <- titanic[-trainIndex ,]

formula1 <- Survived ~ Pclass + Age + Sex + SibSp + Parch + Fare + Embarked
titanicGLM1 <- glm(formula1, data = train, family = binomial)
summary(titanicGLM1)
anova(titanicGLM1, test = "Chisq")

formula2 <- Survived ~ Pclass + Age + Sex + SibSp + Embarked
titanicGLM2 <- glm(formula2, data = train, family = binomial)
summary(titanicGLM2)
anova(titanicGLM2, test = "Chisq")

formula3 <- Survived ~ Pclass + Age + Sex + SibSp
titanicGLM3 <- glm(formula3, data = train, family = binomial)
summary(titanicGLM3)
anova(titanicGLM3, test = "Chisq")

test2 <- na.omit(test)
prediction <- predict(titanicGLM3, newdata = test2, type = "response")
hist(prediction)

optCutOff <- optimalCutoff(test2$Survived, prediction)[1] 

confusionMatrix(test2$Survived, prediction, threshold = optCutOff)

plotROC(test2$Survived, prediction)








